import { Component } from '@angular/core';

@Component({
  selector: 'app-e404',
  imports: [],
  templateUrl: './e404.component.html',
  styleUrl: './e404.component.css'
})
export class E404Component {

}
