import { Component } from '@angular/core';

@Component({
  selector: 'app-o-nas',
  imports: [],
  templateUrl: './o-nas.component.html',
  styleUrl: './o-nas.component.css'
})
export class ONasComponent {

}
