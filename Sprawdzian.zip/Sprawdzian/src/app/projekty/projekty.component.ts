import { Component } from '@angular/core';

@Component({
  selector: 'app-projekty',
  imports: [],
  templateUrl: './projekty.component.html',
  styleUrl: './projekty.component.css'
})
export class ProjektyComponent {

}
