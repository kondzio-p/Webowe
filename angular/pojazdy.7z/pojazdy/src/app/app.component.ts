import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [FormsModule, CommonModule, HttpClientModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  // Zmienne przechowujące pojazy i pojazd
  title = 'Rejestracja pojazdów';
  pojazdy : any[] = [];
  pojazd = {
    marka : '',
    model : '',
    numer_rejestracyjny : '',
    wlasciciel : '',
    email : ''
  };

  // Adres endpointa
  private apiUrl = "http://localhost:3000/pojazdy";
  // Konstruktor klasy HttpClient
  constructor (private http: HttpClient){}

  // Metoda na starcie pobierając pojazdy metodą getPojazdy()
  ngOnInit() {
    this.getPojazdy();
  }

  // Metoda pobierania pojazdów z endpointa
  getPojazdy(){
    this.http.get<any[]>(this.apiUrl).subscribe((data)=>{
      this.pojazdy = data;
    })
  };

  odswiez() {
    window.location.reload();
  }

  addPojazd() {
    this.http.post<any>(this.apiUrl, this.pojazd).subscribe(()=>{
      this.getPojazdy();
      this.pojazd = {marka : '', model : '', numer_rejestracyjny : '', wlasciciel : '', email : ''}
    });
    this.odswiez();
  };

}
    
