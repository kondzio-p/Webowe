import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-kurs',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './kurs.component.html',
  styleUrl: './kurs.component.css'
})
export class KursComponent {
  //Deklaracja listy kursów
  kursy : string[] = ["Programowanie w C#", "Angular dla początkujących", "Kurs Django"];

  //Zmienne dla formularza
  imieNazwisko : string = '';
  numerKursu : number | null = null;
  
  //Funkcja wypisująca dane z formularza na konsolę
  zapiszDoKursu() {
    console.clear();
    console.log('Imię i nazwisko: ', this.imieNazwisko);
    if (this.numerKursu!==null && this.numerKursu > 0 && this.numerKursu <= this.kursy.length) {
      console.log("Wybrany numer kursu: ", this.numerKursu);
      const wybranyKurs = this.kursy[this.numerKursu-1];
      console.log("Wybrany kurs: ", wybranyKurs)
    }
    else {
      console.log('Podano nieprawidłowy numer kursu')
    }
    
  }
}
